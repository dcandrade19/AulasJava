/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servico;

import entidade.Empresa;
import entidade.NotaFiscal;
import java.util.ArrayList;
import persistencia.EmpresaDAO;

/**
 *
 * @author 1718220
 */
public class ServicoEmpresa {
    private EmpresaDAO empresaDAO;

    public ServicoEmpresa(EmpresaDAO empresaDAO) {
        this.empresaDAO = new EmpresaDAO();
    }
    
    public void cadastrarEmpresa(Empresa empresa) {
        
    }
    
    public ArrayList<Empresa> listarEmpresas() {
        return null;
    }
    
    public Empresa buscarEmpresaPorCnpj(String cnpj) {
        return null;
    }
    
    public Empresa excluirEmpresa(Empresa empresa) {
        return null;
    }
    
    public NotaFiscal adicionarNotaFiscal(Empresa empresa, NotaFiscal notaFiscal) {
        return null;
    }
    
    public NotaFiscal cancelarNotaFiscal(Empresa empresa, NotaFiscal notaFiscal) {
        return null;
    }
}
