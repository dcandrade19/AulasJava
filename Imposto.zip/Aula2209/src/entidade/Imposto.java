/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidade;

/**
 *
 * @author 1718220
 */
public abstract class  Imposto {
    
    private static Double aliquotaFederal = 0.1;
    protected Double valor;

    public Imposto(Double valor) {
        this.valor = valor;
    }
    
    public Double calcularImpostoTotal() {
        return calcularImpostoEstadual() + calcularImpostoFederal();
    }
            
    public Double calcularImpostoFederal() {
        return aliquotaFederal * this.valor;
    }
    
    public abstract Double calcularImpostoEstadual();
    
}
