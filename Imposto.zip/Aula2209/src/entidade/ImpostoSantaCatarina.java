/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidade;

/**
 *
 * @author 1718220
 */
public class ImpostoSantaCatarina extends Imposto{

    private static Double aliquotaEstadual = 0.12;
    
    @Override
    public Double calcularImpostoEstadual() {
      return aliquotaEstadual * this.valor;
    }

    public ImpostoSantaCatarina(Double valor) {
        super(valor);
    }
    
}
