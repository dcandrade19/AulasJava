/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidade;

import java.util.Date;

/**
 *
 * @author 1718220
 */
public class NotaFiscal implements Comparable<NotaFiscal>{

    private String numero;
    private String descricao;
    private Date dataEmissao;
    private Imposto imposto;
    private Double valor;
    private Double valorComImposto;
    private Boolean cancelada;

    public NotaFiscal(String numero, String descricao, Date dataEmissao, Imposto imposto, Double valor, Double valorComImposto, Boolean cancelada) {
        this.numero = numero;
        this.descricao = descricao;
        this.dataEmissao = dataEmissao;
        this.imposto = imposto;
        this.valor = valor;
        this.valorComImposto = valorComImposto;
        this.cancelada = cancelada;
    }

    @Override
    public String toString() {
        return "NotaFiscal{" + "numero=" + numero + ", descricao=" + descricao + ", dataEmissao=" + dataEmissao + ", imposto=" + imposto + ", valor=" + valor + ", valorComImposto=" + valorComImposto + ", cancelada=" + cancelada + '}';
    }
    

    
    @Override
    public int compareTo(NotaFiscal o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(Date dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public Imposto getImposto() {
        return imposto;
    }

    public void setImposto(Imposto imposto) {
        this.imposto = imposto;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getValorComImposto() {
        return valorComImposto;
    }

    public void setValorComImposto(Double valorComImposto) {
        this.valorComImposto = valorComImposto;
    }

    public Boolean getCancelada() {
        return cancelada;
    }

    public void setCancelada(Boolean cancelada) {
        this.cancelada = cancelada;
    }

    
    
}
