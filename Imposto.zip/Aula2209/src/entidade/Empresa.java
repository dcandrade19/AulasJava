/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidade;

import java.util.ArrayList;

/**
 *
 * @author 1718220
 */
public class Empresa {
    private String nome;
    private String cnpj;
    private ArrayList<NotaFiscal> notasFiscais;

    public Empresa(String nome, String cnpj, ArrayList<NotaFiscal> notasFiscais) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.notasFiscais = new ArrayList<>();
    }

    public ArrayList<NotaFiscal> getNotasFiscaisValidas() {
       
        return null;
    }
    
     public ArrayList<NotaFiscal> getNotasFiscaisCanceladas() {
        return null;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public ArrayList<NotaFiscal> getNotasFiscais() {
        return notasFiscais;
    }

    public void setNotasFiscais(NotaFiscal notasFiscais) {
        this.notasFiscais.add(notasFiscais);
    }
    
    
}
