/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import entidade.Empresa;
import entidade.NotaFiscal;
import java.util.ArrayList;

/**
 *
 * @author 1718220
 */
public class EmpresaDAO {

    private ArrayList<Empresa> empresas;

    public EmpresaDAO() {
        this.empresas = new ArrayList<Empresa>();
    }

    public Empresa buscarEmpresaPorCnpj(String cnpj) {
        for (Empresa empresa : this.empresas) {
            if (empresa.getCnpj().equalsIgnoreCase(cnpj)) {
                return empresa;
            }
        }
        return null;
    }

    public Empresa salvarEmpresa(Empresa empresa) {
        this.empresas.add(empresa);
        return empresa;
    }

    public ArrayList<Empresa> listarEmpresas() {
        return this.empresas;
    }

    public Empresa excluirEmpresa(Empresa empresa) {
        Empresa paraExcluir = this.buscarEmpresaPorCnpj(empresa.getCnpj());
        if (paraExcluir != null) {
            this.empresas.remove(empresa);
        }
        return paraExcluir;
    }

    public NotaFiscal adicionarNotaFiscal(Empresa empresa, NotaFiscal notaFiscal) {
        Empresa empresaParaAdiconarNota = this.buscarEmpresaPorCnpj(empresa.getCnpj());
        if (empresaParaAdiconarNota != null) {
            empresaParaAdiconarNota.setNotasFiscais(notaFiscal);
            return notaFiscal;
        } else {
            return null;
        }
    }

    public NotaFiscal cancelarNotaFiscal(Empresa empresa, NotaFiscal notaFiscal) {
        Empresa empresaParaCancelarNota = this.buscarEmpresaPorCnpj(empresa.getCnpj());

        if (empresaParaCancelarNota != null) {
            if (empresaParaCancelarNota.getNotasFiscaisValidas().contains(notaFiscal)) {
                notaFiscal.setCancelada(true);
                return notaFiscal;
            }
        }
        return null;
    }
}
