package br.edu.up.ads;

/**
 *  Classe para resolver os exercicios da lista 01
 *  
 * @author Diego
 *
 */
public class Exercicios {
	
	/**
	 * Calcula o E-nesimo termo da Progressao Aritmetica
	 * 
	 * @param a1 - Primeiro termo da PA
	 * @param n - Representa o indice do en�simo termo da PA
	 * @param r - Raz�o da PA
	 * @return - O Enesimo termo da PA
	 */
	public static double calcularEnesimoTermoDaPA(int a1, int n, int r) {
		
		return  a1 + (n-1) * r;
	}
	
	/**
	 *  Efetua o calculo de distancia entre dois pontos
	 * @param x1 
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return
	 */
	public static double calcularDistanciaEntreDoisPontos(int x1, int y1, int x2, int y2) {

		return Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
	}
	/**
	 * Efetua o calculo de media ponderada
	 * @param n1 - Primeira nota
	 * @param n2 - Segunda nota
	 * @param n3 - Terceira nota
	 * @return - Media ponderada das notas
	 */
	public static double calcularMediaAritmetica(double n1,double n2,double n3) {
		
		return (n1 + n2 + n3)/3;
	}
	
	/**
	 *  Efetua o calculo da media Pondera de 3 notas
	 * @param n1 - Primeira nota
	 * @param p1 - Primeiro peso
	 * @param n2 - Segunda nota
	 * @param p2 - Segundo peso
	 * @param n3 - Primeira nota
	 * @param p3 - Primeiro peso
	 * @return - Meida pondera das tres notas
	 */
	public static double calcularMediaPonderada(double n1, int p1,double n2, int p2, double n3, int p3) {
		
		return (((n1 * p1) + (n2 *p2) + (n3 * p3)) / (p1 + p2 +p3));
	}
	
	public static double calculaMediaHarmonica(double n1, double n2, double n3) {
		
		return (3 / ((1/n1) + (1/n2) + (1/n3)));
	}
	
	public static double converteTemperaturaCelciusParaFahrenheit(double t) {
		
		return ((9 * t) + 160) / 5;
	}
	
	public static double calculaVolumeCilindro(double r, double a) {
		
		return Math.PI * (Math.pow(r, 2)) * a;
	}
	
	public static double calculoConsumo(double tempo, double velocidade) {
		
		return ((tempo * velocidade) / 12);
	}
	
	public static double calculoAcrescimo(double valor) {
		
		return valor*1.15;
	}
	
}
