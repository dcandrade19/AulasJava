package br.edu.up.ads;


// Main
public class Principal {
	
	public static void main(String[] args) {
		
		int a1 = 10;
	    int n = 7;
		int r = 3;
		int x1 = 0, x2 = 10, y1 = 5, y2 =20;
		double n1 = 10, n2 = 5.5, n3 = 8;
		int p1 = 2, p2 = 3, p3 = 4;
		double t = 30;
		double raio = 10, a = 15;
		double tempo = 1, velocidade = 60;
		double valor = 100;
		
		double an = Exercicios.calcularEnesimoTermoDaPA(a1, n, r);
		
		double ab = Exercicios.calcularDistanciaEntreDoisPontos(x1, y1, x2, y2);
		
		double ac = Exercicios.calcularMediaAritmetica(n1, n2, n3);
		
		double ad = Exercicios.calcularMediaPonderada(n1, p1, n2, p2, n3, p3);
		
		double ae = Exercicios.calculaMediaHarmonica(n1, n2, n3);
		
		double af = Exercicios.converteTemperaturaCelciusParaFahrenheit(t);
		
		double ag = Exercicios.calculaVolumeCilindro(raio, a);
		
		double ah = Exercicios.calculoConsumo(tempo, velocidade);
		
		double ai = Exercicios.calculoAcrescimo(valor);
		
		System.out.println("O enesimo termo �: " + an);
		System.out.printf("A distancia entre os dois pontos �: %.2f \n" ,ab);
		System.out.printf("A media �: %.2f \n" ,ac);
		System.out.printf("A media ponderada �: %.2f \n" ,ad);
		System.out.printf("A media harmonica �: %.2f \n" ,ae);
		System.out.println("A temperatura convertida �: " + af);
		System.out.printf("O volume �: %.2f \n" ,ag);
		System.out.printf("O consumo �: %.2f \n" ,ah);
		System.out.printf("O valor com acrescimo �: %.2f \n" ,ai);
	}


	
}
